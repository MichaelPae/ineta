#! /usr/bin/env python3
# -------------------------------------------
# Klassen 3
# -------------------------------------------

class Fahrzeug():
    def __init__(self, typ, antrieb):
        self.typ = typ
        self.antrieb = antrieb

class Auto(Fahrzeug):
    def __init__(self, antrieb, sitze, gewicht):
        super().__init__("Auto",antrieb)
        self.sitze = sitze
        self.raeder = 4
        self.gewicht = gewicht

    def toString(self):
        text = "Fahrzeug: " \
               + self.antrieb + "-"+ self.typ + " mit " \
               + str(self.sitze) + " Sitzen, " \
               + str(self.raeder) + " Rädern und " \
               + str(self.gewicht) + " kg Gewicht"
               
        return(text)

class Motorad(Fahrzeug):
    def __init__(self, antrieb, sitze, gewicht):
        super().__init__("Motorad",antrieb)
        self.sitze = sitze
        self.raeder = 2
        self.gewicht = gewicht

    def toString(self):
        text = "Fahrzeug: " \
               + self.antrieb + "-"+ self.typ + " mit " \
               + str(self.sitze) + " Sitzen, " \
               + str(self.raeder) + " Rädern und " \
               + str(self.gewicht) + " kg Gewicht"
               
        return(text)






f1 = Auto("Diesel",5,2500)
print(f1.toString())
f1.gewicht = 1950
print(f1.toString())



f2 = Motorad("Elektro",2,400)
print(f2.toString())












print("---ENDE-------------------------------------------------")    

