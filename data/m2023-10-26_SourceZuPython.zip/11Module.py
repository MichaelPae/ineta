#! /usr/bin/env python3
# -------------------------------------------
# Module
# -------------------------------------------
import meinzufall as mz


# Hauptprogramm
eingabe = int(input("Wieviel Zufallszahlen sollen erzeugt werden? Gib eine Zahl an: "))

zufallsliste = mz.erstelleZufallsliste(eingabe)

mittelwert = mz.berechneMittelwert(zufallsliste)

print("Das Mittelwert beträgt " + str(mittelwert) + ".")

print("---ENDE-------------------------------------------------")    

