#! /usr/bin/env python3
# -------------------------------------------
# Fenster 2 Buttons, 2 Labels
# -------------------------------------------
import tkinter as tk

def button_action():
    lbAnweisung.config(text="Bin angeklickt...")



fenster = tk.Tk()

fenster.title( "Schönes Testfenster" )
fenster.geometry("1020x600")

# Buttons erstellen.
btnAendern = tk.Button(fenster, text="Ändern", command=button_action)
btnEnde = tk.Button(fenster, text="Beenden", command=fenster.quit)

# Labels erstellen.
lbAnweisung = tk.Label(fenster, text="Ich bin eine Anweisung:\nKlicke auf 'Ändern'.")
lbInfo = tk.Label(fenster, text="Ich bin eine Info:\nDer Beenden Button schließt das Programm.")

# Komponenten in der gewünschten Reihenfolge hinzufügen
lbAnweisung.pack()
btnAendern.pack()
lbInfo.pack()
btnEnde.pack()


fenster.mainloop()

