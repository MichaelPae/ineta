#! /usr/bin/env python3
# -------------------------------------------
# Funktionen
# -------------------------------------------
# import random as r
from random import randint
# Funktion 1

def f0():
    print(a)

def f1(x):
    x += 2
    return x

# Funktion 2
def f2():
    a = 0
    print("In f2 a=",a)

# Hauptprogramm
a = "Frosch"

f0()
a = f1(1)
print(a)
f2()
print(a)
print("---ENDE-------------------------------------------------")    

