#! /usr/bin/env python3
# -------------------------------------------
# Tkinter = Tool Kit Interface
# -------------------------------------------
# Tk stellt die folgenden Widgets zur Verfügung:
# - button
# - canvas
# - checkbutton
# - combobox
# - entry
# - frame
# - label
# - labelframe
# - listbox
# - menu
# - menubutton
# - message
# - notebook
# - tk_optionMenu
# - panedwindow
# - progressbar
# - radiobutton
# - scale
# - scrollbar
# - separator
# - sizegrip
# - spinbox
# - text
# - treeview
# -------------------------------------------
# Außerdem stellt es die folgenden Fenster auf höchster Ebene zur Verfügung:
# - tk_chooseColor - lässt ein Pop-up-Fenster erscheinen, dass es dem Benutzer ermöglicht eine Farbe aus einer Palette auszuwählen.
# - tk_chooseDirectory - Pop-up-Fenster, dass einem Benutzer erlaubt interaktiv ein Verzeichnis auszuwählen.
# - tk_dialog - ein Pop-up-Fenster in Form eines Dialogfenster
# - tk_getOpenFile - Pop-up-Fenster, dass einem Benutzer erlaubt interaktiv eine Datei zum Öffnen auszuwählen.
# - tk_getSaveFile - Pop-up-Fenster, dass einem Benutzer erlaubt interaktiv eine Datei zum Schreiben auszuwählen.
# - tk_messageBox - Pop-up-Fenster mit Message.
# - tk_popup - Pop-up-Fenster.
# - toplevel - erzeugt und verändert Widgets auf höchster Ebene.
# -------------------------------------------
# Tk stellt drei verschiede Geometrie-Manager zur Verfügung:
# - place
# - grid
# - pack
# -------------------------------------------



import tkinter as tk


fenster = tk.Tk()
fenster.title( "Schönes Testfenster" )
fenster.geometry("1020x600")


fenster.mainloop()
