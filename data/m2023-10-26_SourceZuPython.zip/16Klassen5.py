#! /usr/bin/env python3
# -------------------------------------------
# Klassen 5
# -------------------------------------------

class Fahrzeug():
    def __init__(self, typ, antrieb):
        self.__typ = typ
        self.__antrieb = antrieb
        self.__hubraum = 0
    # ------------------------------------------
    @property
    def typ(self):
        return self.__typ
    @typ.setter
    def typ(self,newvalue):
        self.__typ = newvalue        

    # ------------------------------------------
    @property
    def antrieb(self):
        return self.__antrieb
    @antrieb.setter
    def antrieb(self,newvalue):
        self.__antrieb = newvalue        

    # ------------------------------------------
    @property
    def hubraum(self):
        return self.__hubraum
    @hubraum.setter
    def hubraum(self,newvalue):
        if self.__antrieb == "Elektro":
            self.__hubraum = 0
        else:
            self.__hubraum = newvalue        

# ------------------------------------------
class Auto(Fahrzeug):
    def __init__(self, antrieb, sitze, gewicht):
        super().__init__("Auto",antrieb)
        self.sitze = sitze
        self.raeder = 4
        self.gewicht = gewicht

    def toString(self):
        text = "Fahrzeug: " \
               + self.antrieb + "-"+ self.typ + " mit " \
               + str(self.sitze) + " Sitzen, " \
               + str(self.raeder) + " Rädern und " \
               + str(self.gewicht) + " kg Gewicht, " \
               + str(self.hubraum) + " ccm Hubraum"
               
        return(text)

class Motorad(Fahrzeug):
    def __init__(self, antrieb, sitze, gewicht):
        super().__init__("Motorad",antrieb)
        self.sitze = sitze
        self.raeder = 2
        self.gewicht = gewicht

    def toString(self):
        text = "Fahrzeug: " \
               + self.antrieb + "-"+ self.typ + " mit " \
               + str(self.sitze) + " Sitzen, " \
               + str(self.raeder) + " Rädern und " \
               + str(self.gewicht) + " kg Gewicht, " \
               + str(self.hubraum) + " ccm Hubraum"
               
        return(text)


f1 = Auto("Diesel",5,2500)
print(f1.toString())
f1.gewicht = 1950
f1.hubraum = 1600
print(f1.toString())


f2 = Motorad("Elektro",2,400)
print(f2.toString())
f2.hubraum = 1000
print(f2.toString())












print("---ENDE-------------------------------------------------")    

