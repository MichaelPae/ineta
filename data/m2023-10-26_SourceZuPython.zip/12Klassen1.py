#! /usr/bin/env python3
# -------------------------------------------
# Klassen
# -------------------------------------------

class Fahrzeug:
    pass


f1 = Fahrzeug()
f1.Typ = "Auto"
f1.Sitze = 5
f1.Raeder = 4

print("Typ:", f1.Typ)
print( "Räder:", f1.Raeder)
print( "Sitze:", f1.Sitze )












print("---ENDE-------------------------------------------------")    

