#! /usr/bin/env python3
# -------------------------------------------
# Tkinter = Tool Kit Interface
# -------------------------------------------
import tkinter as tk


fenster = tk.Tk()
fenster.title( "Schönes Testfenster" )
fenster.geometry("1020x600")


fenster.mainloop()

