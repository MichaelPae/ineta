#! /usr/bin/env python3
# -------------------------------------------
# Mehrere Rückgabewerte
# -------------------------------------------
from random import randint as rdi

def HoleAlleWerte():
    zahl = rdi(0,100)
    zeichen = "Akte"
    liste = (1,2,3)

    return zahl, zeichen, liste

# Hauptprogramm
a,b,c = HoleAlleWerte()
print(a,b,c)

print("---ENDE-------------------------------------------------")    

