
# -------------------------------------------
# Klassen 4
# -------------------------------------------

class MyClass():
    def __init__(self):
        self.pub = "Ich bin öffentlich"
        self._prot = "Ich bin protected"
        self.__priv = "Ich bin privat"

x = MyClass()
x.pub
x._prot
x.__priv

