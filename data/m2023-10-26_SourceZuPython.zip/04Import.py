#! /usr/bin/env python3

# -------------------------------------------
# Import-Befehl
# -------------------------------------------
# import sys as s
from sys import set_int_max_str_digits

set_int_max_str_digits(20000)

c=25
d = c ** 12345

print(d)
print("Ergebnis von ",c,"hoch 12345")
print("Typ", type(d))
print("Länge", len(str(d)))


print("---ENDE-------------------------------------------------")    

