#! /usr/bin/env python3

# -------------------------------------------
# Variablennamen
# -------------------------------------------
# Buchstaben, Zahlen, Unterstrich
# Keine Leerstellen, umlaute
# -------------------------------------------

eine_Zahl = 42
nochEineZahl = 11
__unerwuenscht = 13

print(__unerwuenscht)



# -------------------------------------------
# String
# -------------------------------------------
# c = input("Wie ist dein Name? ")
# print("Dein Name ist",c)
c = "Alle Affen fallen ins Wasser"
a = c.count("A")

print("a kommt",a," mal vor")
c1 = c[5:10]
print(c,c1)
a = c.count("A")
print("a kommt",a," mal vor")


# -------------------------------------------
# Int
# -------------------------------------------
i = 3
print(i, "ist vom Typ", type(i))

i = 42**1234
print(i, "ist vom Typ", type(i))


# -------------------------------------------
# Komplexe Zahlen
# -------------------------------------------
x = 3+4j
print(x, "ist vom Typ", type(x))



# -------------------------------------------
# Boolsche Werte
# -------------------------------------------
x = bool(1)
c = False
print(x, "ist vom Typ", type(x))
x = (3==4)
print(x, "ist vom Typ", type(x))

w = 4.5

print(w, "ist vom Typ", type(w))




print("---ENDE-------------------------------------------------")    

