#! /usr/bin/env python3
# -------------------------------------------
# Exceptions
# -------------------------------------------
import sys
sys.set_int_max_str_digits(2000)

c=25
try:
    print( c**12345 )
except BaseException as err:
    print("Es ist ein Fehler aufgetreten: ", err)
    # pass
finally:
    print("---ENDE-------------------------------------------------")    

