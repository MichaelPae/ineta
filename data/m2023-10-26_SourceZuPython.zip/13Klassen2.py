#! /usr/bin/env python3
# -------------------------------------------
# Klassen 2
# -------------------------------------------

class Fahrzeug:
    def __init__(self, typ, sitze, raeder, gewicht):
        self.typ = typ
        self.sitze = sitze
        self.raeder = raeder
        self.gewicht = gewicht

    def toString(self):
        text = "Fahrzeug vom Typ " \
               + self.typ + " mit " \
               + str(self.sitze) + " Sitzen, " \
               + str(self.raeder) + " Rädern und " \
               + str(self.gewicht) + " kg Gewicht"
               
        return(text)


f1 = Fahrzeug("Auto",5,4,2000)
f2 = Fahrzeug("Motorad",2,2,450)

print(f1.toString())
print(f2.toString())











print("---ENDE-------------------------------------------------")    

