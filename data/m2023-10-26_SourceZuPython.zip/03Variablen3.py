#! /usr/bin/env python3

# -------------------------------------------
# Listen
# -------------------------------------------

liste = [42, 'Usergroup', ['Pi', 3.14], 2.44]

a = liste[0]
b = liste[1]
c = liste[2]
d = liste[3]

print(liste)
print(a,b,c,d)

liste.append(False)


# Elemet ersetzen
liste[2] = 666
#Länge der Liste
len(liste)
# Neues Element anhängen
liste.append('Alles')
# Zweite Liste anhängen
liste.extend([4, 5, 3.14])
# Element an Stelle 2 einfügen
liste.insert(2, 'Hotel')
# Inhalt zählen
liste.count(3.14)
# Index eines Elements
liste.index(3.14)
# Element mit bestimmten Wert entfernen
liste.remove(3.14)
# Letztes Element der Liste holen und aus Liste entfernen
liste.pop()
# Reihenfolge der Listenelemente umkehren
liste.reverse()
# Listenelemente summieren
sum([1,3,5])










# -------------------------------------------
# Weitere Datentypen
# Sets
s = {1,2,3}
# Dictionaries
d = {1:'rot', 2:'gelb', 3:'grün'}
# -------------------------------------------

print("---ENDE-------------------------------------------------")    

