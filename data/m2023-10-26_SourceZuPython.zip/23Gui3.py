#! /usr/bin/env python3
# -------------------------------------------
# Fenster 2 Buttons, 2 Labels
# -------------------------------------------
import tkinter as tk
from tkinter import filedialog as fd

class MeinSchoenesFenster:

    def __init__(self):
        self.rootWin = tk.Tk()
        self.rootWin.title("Mein Schönes Fenster")
        self.rootWin.geometry("1020x600")
        self.text = ""
        self.filename=""
        self._setup()

    def _setup(self):

        # -----------------------------------------
        # frameOben
        # -----------------------------------------
        frameOben = tk.Frame(self.rootWin)
        frameOben.pack(fill='both', expand=False)
        #
        self.btnEinlesen = tk.Button(frameOben, text="Einlesen", command=self.einlesen)
        self.btnEinlesen.pack(side="left", padx=10, pady=10)
        self.btnEinlesen.configure(state=tk.NORMAL)
        #
        self.btnSpeichern = tk.Button(frameOben, text="Speichern", command=self.speichern)
        self.btnSpeichern.pack(side="left", padx=10, pady=10)
        self.btnSpeichern.configure(state=tk.DISABLED)
        #
        self.btnEnde = tk.Button(frameOben, text="Ende", command=self.ende)
        self.btnEnde.pack(side="right", padx=10, pady=10)
        #
        # -----------------------------------------
        # frameUnten
        # -----------------------------------------
        frameUnten = tk.Frame(self.rootWin)
        frameUnten.pack(fill='both', expand=True, padx=10, pady=10)
        self.tbBox = tk.Text(frameUnten, width=1000, height=400,wrap="word")
        self.tbBox.pack(side="top",padx=10, pady=10)

    def start(self):
        self.rootWin.mainloop()

    def ende(self):
        self.rootWin.destroy()
        self.rootWin.quit()

    def einlesen(self):
        typen = (('text files', '*.txt'),('All files', '*.*'))
        self.filename = fd.askopenfilename(title='Datei öffnen', initialdir='./',filetypes=typen)
        self.datei = open(self.filename,'r')
        self.text =self.datei.read()
        self.tbBox.delete(1.0, "end")
        self.tbBox.insert(1.0, self.text)
        self.btnSpeichern.configure(state=tk.NORMAL)

    def speichern(self):
        self.text = self.tbBox.get(1.0, "end")
        self.datei = open(self.filename,'w')
        self.datei.write(self.text)
        self.tbBox.delete(1.0, "end")
        self.btnSpeichern.configure(state=tk.DISABLED)

        


win = MeinSchoenesFenster()
win.start()
