#! /usr/bin/env python3

# -------------------------------------------
# Blöcke
# -------------------------------------------

# -------------------------------------------
# IF
# -------------------------------------------
x = 2
if x == 2:
    pass
    # print("x ist 2")
elif x == 5:
    pass
else:

    print("x ist nicht 2. x ist",x)
    

# -------------------------------------------
# FOR
# -------------------------------------------

summe = 0
for zahl in [1,2,3,5,7,11,13,17]:
    print("Addiere", zahl, "zu", summe)
    summe = summe + zahl
    print("    Summe =", summe)

print("Fertig!")


liste = list(range(1,51))
for zahl in liste:
    print(zahl)




# -------------------------------------------
# FOR
# -------------------------------------------

erg = input("Willst du dein ganzes Geld verschenken?  Ja oder Nein (J/N): ")

while erg not in ['j', 'J']:
    print("Falsche Antwort! Versuch es noch einmal.")
    erg = input("-->Willst du dein ganzes Geld verschenken?  Ja oder Nein (J/N): ")

print("Vielen Dank! Meine Kontonummer lautet DE44 2605 0051 0000 1259 49")





print("---ENDE-------------------------------------------------")    

