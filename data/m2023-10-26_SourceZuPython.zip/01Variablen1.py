#! /usr/bin/env python3

# Kommentar



''' extrem langer 
Kommentar über
mehrere Zeilen
'''
""" so geht es auch
Hallo
"""






a=5
b=10
print(a+b)

c = "Hallo"
print(c,b)

# Achtung! Das ist auch möglich!
c=5**2

# -------------------------------------------
# Mehrzeilige Anweisungen
# -------------------------------------------
a = 1 + 2 + 3 + \
    4 + 5

print(a, c,"=", b)
print("---ENDE-------------------------------------------------")

