#! /usr/bin/env python3
# -------------------------------------------
# Lambda Funktionen (anonyme Funktionen)
# -------------------------------------------
from random import randint as rdi

def Quadriere(x):
    a = x**2
    return a

# Hauptprogramm
a = 10
f = lambda x: x**2
g = lambda x,y: (x+a)*y
zahl = int( input("Gib eine Zahl ein:"))
while zahl > 0:
    print("Funktion:",zahl, "zum Quadrat ergibt", Quadriere(zahl))
    print("Lambda:",  zahl, "zum Quadrat ergibt", f(zahl))
    parameter = 5
    print(parameter,"+",a,"mal",zahl,"ergibt", g(parameter,zahl))
    zahl = int( input("Gib eine neue Zahl ein:"))

print("---ENDE-------------------------------------------------")    

