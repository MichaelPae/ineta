#! /usr/bin/env python3
# -------------------------------------------
# Zufallsmodul
# -------------------------------------------

from random import randint


def erstelleZufallsliste(meineZahl):
    liste = []
    for i in range(meineZahl):
        liste.append(randint(0,100))
    return liste

def berechneMittelwert(zufallszahlenListe):
    result = 0
    for i in range(len(zufallszahlenListe)):
        result = result + zufallszahlenListe[i]

    result = result / len(zufallszahlenListe)
    return result
