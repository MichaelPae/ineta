#! /usr/bin/env python3
# -------------------------------------------
# Exceptions
# -------------------------------------------
# import random as r
from random import randint


def erstelleZufallsliste(meineZahl):
    liste = []
    for i in range(meineZahl):
        liste.append(randint(0,100))
    return liste

def berechneMittelwert(zufallszahlenListe):
    result = 0
    for i in range(len(zufallszahlenListe)):
        result = result + zufallszahlenListe[i]

    result = result / len(zufallszahlenListe)

    print("Das Mittelwert beträgt " + str(result) + ".")


# Hauptprogramm
eingabe = int(input("Wieviel Zufallszahlen sollen erzeugt werden? Gib eine Zahl an: "))

zufallsliste = erstelleZufallsliste(eingabe)

berechneMittelwert(zufallsliste)

print("---ENDE-------------------------------------------------")    

